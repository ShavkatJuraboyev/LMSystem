from django import forms
from .models import Role, UserRoleAssignment


class BootstrapFormMixin:
    def _add_bootstrap_classes(self):
        for field_name, field in self.fields.items():
            widget = field.widget

            if isinstance(widget, forms.CheckboxInput):
                widget.attrs.update({"class": "form-check-input"})
            elif isinstance(widget, forms.Select):
                widget.attrs.update({"class": "form-select"})
            elif isinstance(widget, forms.Textarea):
                widget.attrs.update({"class": "form-control"})
            else:
                widget.attrs.update({"class": "form-control"})


class RoleForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Role
        fields = [
            "organization",
            "name",
            "code",
            "role_type",
            "description",
            "is_system",
            "is_active",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._add_bootstrap_classes()


class UserRoleAssignmentForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = UserRoleAssignment
        fields = [
            "user",
            "role",
            "organization",
            "faculty",
            "department",
            "group",
            "subject",
            "starts_at",
            "ends_at",
            "is_active",
        ]
        widgets = {
            "starts_at": forms.DateTimeInput(attrs={"type": "datetime-local"}),
            "ends_at": forms.DateTimeInput(attrs={"type": "datetime-local"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._add_bootstrap_classes()
