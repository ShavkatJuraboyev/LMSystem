from django.shortcuts import redirect, render, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth.decorators import login_required

from structure.models import Organization
from .forms import RoleForm, UserRoleAssignmentForm
from .models import Permission, Role, UserRoleAssignment, RolePermission


 
def login_view(request):

    if request.user.is_authenticated:
        return redirect("dashboard")

    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect('dashboard')

        messages.error(
            request,
            "Login yoki parol noto‘g‘ri"
        )

    return render(request, 'accounts/login.html')


@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "Siz muvaffaqiyatli tizimdan chiqdingiz.")
    return redirect("login")



@login_required
def role_list(request):
    roles = Role.objects.select_related("organization").prefetch_related("role_permissions")

    q = request.GET.get("q")
    status = request.GET.get("status")

    if q:
        roles = roles.filter(
            Q(name__icontains=q) |
            Q(code__icontains=q) |
            Q(description__icontains=q)
        )

    if status == "active":
        roles = roles.filter(is_active=True)
    elif status == "inactive":
        roles = roles.filter(is_active=False)

    context = {
        "roles": roles.order_by("role_type", "name"),
        "active_roles_count": Role.objects.filter(is_active=True).count(),
        "inactive_roles_count": Role.objects.filter(is_active=False).count(),
        "system_roles_count": Role.objects.filter(is_system=True).count(),
    }
    return render(request, "accounts/roles/role_list.html", context)


@login_required
def role_create(request):
    if request.method == "POST":
        form = RoleForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Rol muvaffaqiyatli yaratildi.")
            return redirect("role_list")
    else:
        form = RoleForm()

    return render(request, "accounts/roles/role_form.html", {
        "form": form,
        "title": "Yangi rol yaratish",
    })


@login_required
def role_edit(request, pk):
    role = get_object_or_404(Role, pk=pk)

    if request.method == "POST":
        form = RoleForm(request.POST, instance=role)
        if form.is_valid():
            form.save()
            messages.success(request, "Rol muvaffaqiyatli yangilandi.")
            return redirect("role_list")
    else:
        form = RoleForm(instance=role)

    return render(request, "accounts/roles/role_form.html", {
        "form": form,
        "title": "Rolni tahrirlash",
    })


@login_required
def role_delete(request, pk):
    role = get_object_or_404(Role, pk=pk)

    if role.is_system:
        messages.error(request, "Tizim rolini o‘chirish mumkin emas.")
        return redirect("role_list")

    if request.method == "POST":
        role.delete()
        messages.success(request, "Rol o‘chirildi.")

    return redirect("role_list")


@login_required
def user_role_list(request):
    user_roles = UserRoleAssignment.objects.select_related(
        "user", "role", "organization", "faculty", "department", "group", "subject"
    )

    q = request.GET.get("q")
    if q:
        user_roles = user_roles.filter(
            Q(user__username__icontains=q) |
            Q(user__first_name__icontains=q) |
            Q(user__last_name__icontains=q) |
            Q(role__name__icontains=q)
        )

    return render(request, "accounts/roles/user_role_list.html", {
        "user_roles": user_roles.order_by("-created_at"),
    })


@login_required
def user_role_create(request):
    if request.method == "POST":
        form = UserRoleAssignmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Foydalanuvchiga rol biriktirildi.")
            return redirect("user_role_list")
    else:
        form = UserRoleAssignmentForm()

    return render(request, "accounts/roles/user_role_form.html", {
        "form": form,
        "title": "Foydalanuvchiga rol biriktirish",
    })


@login_required
def user_role_edit(request, pk):
    user_role = get_object_or_404(UserRoleAssignment, pk=pk)

    if request.method == "POST":
        form = UserRoleAssignmentForm(request.POST, instance=user_role)
        if form.is_valid():
            form.save()
            messages.success(request, "Foydalanuvchi roli yangilandi.")
            return redirect("user_role_list")
    else:
        form = UserRoleAssignmentForm(instance=user_role)

    return render(request, "accounts/roles/user_role_form.html", {
        "form": form,
        "title": "Foydalanuvchi rolini tahrirlash",
    })


@login_required
def user_role_delete(request, pk):
    user_role = get_object_or_404(UserRoleAssignment, pk=pk)

    if request.method == "POST":
        user_role.delete()
        messages.success(request, "Biriktirilgan rol o‘chirildi.")

    return redirect("user_role_list")


@login_required
def role_permission_update(request, pk):
    role = get_object_or_404(Role, pk=pk)
    permissions = Permission.objects.select_related("module").all()

    if request.method == "POST":
        permission_ids = request.POST.getlist("permissions")

        role.role_permissions.all().delete()

        for permission_id in permission_ids:
            RolePermission.objects.create(
                role=role,
                permission_id=permission_id
            )

        messages.success(request, "Rol ruxsatlari muvaffaqiyatli yangilandi.")
        return redirect("role_list")

    selected_permissions = role.role_permissions.values_list(
        "permission_id",
        flat=True
    )

    return render(request, "accounts/roles/role_permission_form.html", {
        "role": role,
        "permissions": permissions,
        "selected_permissions": selected_permissions,
    })