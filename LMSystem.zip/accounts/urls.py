from django.urls import path
from .views import (
    login_view, logout_view, 
    role_delete, role_list, role_create, role_edit, role_permission_update, 
    user_role_list, user_role_create, user_role_edit, user_role_delete
    )

urlpatterns = [
    path("login/", login_view, name="login"),
    path("logout/", logout_view, name="logout"),

    path("roles/", role_list, name="role_list"),
    path("roles/create/", role_create, name="role_create"),
    path("roles/<uuid:pk>/edit/", role_edit, name="role_edit"),
    path("roles/<uuid:pk>/delete/", role_delete, name="role_delete"),

    path("user-roles/", user_role_list, name="user_role_list"),
    path("user-roles/create/", user_role_create, name="user_role_create"),
    path("user-roles/<uuid:pk>/edit/", user_role_edit, name="user_role_edit"),
    path("user-roles/<uuid:pk>/delete/", user_role_delete, name="user_role_delete"),

    path("roles/<uuid:pk>/permissions/", role_permission_update, name="role_permission_update"
),
]